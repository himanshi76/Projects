# linear-regression-and-Additive-models
Hello, and welcome to my sixth project on Linear Regression Models and Improving Predictions and lastly applying Additive Model on Kickstarter Dataset (Crowd funding Dataset).
